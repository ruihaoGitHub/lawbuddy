# BlinkMimic Core Data Flow

This archive contains the in-repository code needed to understand BlinkMimic's
world model, real-simulator collection, replay data, imagined policy training,
critics, reset allocation, and data entry points. It excludes motion/checkpoint
data, logs, the Git database, dependency lock files, and static media.

## Entry point and released recipe

- `scripts/train.sh` starts `python -m blinkmimic.train`.
- `scripts/presets.sh` defines the released `main` recipe.
- `src/blinkmimic/train.py` parses all flags, constructs every component, and
  alternates collection, world-model updates, and policy updates.
- `tools/download_data.sh` downloads the 40 G1-retargeted LAFAN1 clips and G1
  description from Hugging Face. Motion and robot meshes are runtime data and are
  not bundled.

## Robot, motion, and state representations

- `src/blinkmimic/robot.py` loads a robot-specific `RobotSpec`.
- `src/blinkmimic/g1/g1_constants.py` defines G1 joints, tracked bodies,
  actuator scales, motion loader, sensing, and domain randomization.
- `src/blinkmimic/motion.py` loads 50 Hz reference clips, computes root/body
  velocities and accelerations, builds future goal windows, and divides motion
  timelines into one-second reset bins.
- `src/blinkmimic/kinematics.py` provides batched forward kinematics.
- `src/blinkmimic/rotations.py` provides matrix/quaternion/axis-angle operations.
- `src/blinkmimic/mdp.py` defines the shared six-block state:
  `(root position, root rotation, root linear velocity, root angular velocity,
  joint positions, joint velocities)`.

## Real-simulator collection

`src/blinkmimic/env.py::TrackingSim` is the batched MuJoCo-Warp environment.

One collection step:

1. `env.observe()` returns robot-state sensing and observation history.
2. `motion.goal(env.f, K)` creates `K` future reference frames.
3. `Policy` consumes observation history plus the motion goal.
4. Optional action noise is applied and raw actions are clamped.
5. `env.step(a)` or `env.step_core(a)` advances MuJoCo-Warp.
6. The MDP computes tracking reward and hard/soft termination.
7. Episode reset state and 1-second reset-bin statistics are updated.
8. The transition is written to `ReplayBuffer`.

The real environment state and domains are:

- full state: `S = (p, R, v, w, q, qd)`
- policy observation: joint position/velocity, angular velocity, gravity,
  previous action, and reference-relative root orientation
- sim context `xi`: normalized friction, encoder offsets, CoM, and optional
  mass/contact/actuator/push parameters

## Replay data

`src/blinkmimic/buffer.py::ReplayBuffer` stores fixed `(time, environment)`
transition tensors on GPU:

`s, s1, a, a_prev, xi, r, f, ep_step, done, cut`

It also optionally stores stateful-sensing observation and sensing state.

Sampling APIs:

- `sample_windows()` returns causal world-model sequences and a validity mask.
- `sample_starts()` returns imagined-rollout start states and observation
  histories.

## World-model design

`src/blinkmimic/networks.py::WorldModel` predicts frame-local state increments.

Inputs:

`(invariant state features, action, optional previous action, normalized xi)`

Outputs:

root position increment, root rotation increment, linear-velocity increment,
angular-velocity increment, joint-position increment, and joint-velocity
increment.

The optional `structured` mode uses semi-implicit integration:

- predicts velocity increments and joint velocity increments
- integrates positions with a 0.625 old/new velocity drift coefficient
- predicts corrections on top of position and joint-position drift

World-model training in `train.py::wm_update()`:

1. Sample replay windows.
2. Optionally left-right mirror a fraction of the batch.
3. Roll `WorldModel` autoregressively through `wm_window` steps.
4. Compare normalized state errors against `S1` targets.
5. Clip gradients and update the world-model network.

The action delay, if present, makes `a_prev` part of the transition input.

## Policy and critic models

`src/blinkmimic/networks.py::Policy`

- motion goal encoder
- shared observation-history decoder
- 32-dimensional tanh-bounded latent
- optional reference-action skip connection

The observation history is latest frame first? It is stored oldest-to-newest
and shifted right each imagined/real step.

`src/blinkmimic/networks.py::Critic`

Critic input contains invariant state features, motion/goal information,
reference tracking errors, and normalized sim context.

## Imagined policy training

`src/blinkmimic/train.py::policy_update()` starts from replay-buffer states.

1. Sample valid start states and observation histories.
2. Freeze world-model and critic parameters.
3. Roll the policy and world model for `horizon=32`.
4. Recompute goals and observations/sensing for each imagined step.
5. Compute tracking reward and differentiable soft termination.
6. Maximize discounted survival-masked imagined return:
   `J = sum gamma^t c_t r_t + gamma^H c_H V(s_H)`.
7. Apply policy gradient clipping and policy optimizer updates.
8. Compute GAE(lambda) critic targets from imagined rewards and values.
9. Fit the critic with multiple epochs/minibatches.

`src/blinkmimic/objective.py` implements survival masking and the SHAC objective.
`src/blinkmimic/mdp.py` supplies the tracking reward, contact reward, and soft
termination shared with real and imagined environments.

## Reset allocation

The real simulator partitions reference motion into 1-second bins.
`TrackingSim.sample_frames()` mixes:

- 50% uniform across bins
- 40% softmax focusing on low estimated per-bin return
- 10% a moving estimate of bin return
- optional reset share one bin before recent failures
- optional evaluation-guided failures identified by periodic probe sweeps

The probe sweep in `train.py` runs the deployed EMA policy under
evaluation-condition worlds, identifies first-failure bins, then mixes those
failure windows into the real reset distribution.

## Complete loop

Every training iteration:

1. Update the learning-rate schedule and optional evaluation-probe state.
2. Collect one or more real-simulator control steps.
3. Update replay and running normalizers.
4. Update the world model several times.
5. After world-model warmup, sample imagined starts and update policy and critic.
6. Update policy EMA.
7. Log metrics and save checkpoints.

The released `main` preset enables EMA, structured world model, mirror
augmentation, Muon, reference-action skip, reset fixes, evaluation-guided resets,
and CUDA-graph/side-stream optimizations.
