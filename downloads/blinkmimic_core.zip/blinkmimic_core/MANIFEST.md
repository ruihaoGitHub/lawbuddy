# Archive Manifest

- `DATA_FLOW.md`: concise implementation and data-flow guide
- `README.md`: setup, usage, released recipe, and method attribution
- `scripts/train.sh`: released-training launcher
- `scripts/presets.sh`: baseline, InstantTrack, and BlinkMimic presets
- `tools/download_data.sh`: motion/data download script
- `tools/test_env.py`: environment sanity check
- `tools/eval_batch.py`, `tools/eval_metrics.py`: evaluation entry points
- `tools/export_onnx.py`, `tools/play_onnx.py`: deployment export/check
- `src/blinkmimic/*.py`: core world model, replay, MDP, sensing, reset,
  policy/critic, motion, kinematics, optimization, mirroring, and training
- `src/blinkmimic/g1/g1_constants.py`: G1 robot and data-format configuration
