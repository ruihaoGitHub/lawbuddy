# SuperMimic Core Data Flow

This archive contains the in-repository implementation needed to understand the
SuperMimic world-model and policy training loop. It intentionally excludes motion
assets, checkpoints, logs, the Git database, tests, and dependency lock/vendor
content.

## 1. Entry point

`src/supermimic/scripts/train.py`

- Parses the task ID and runner/environment config.
- Downloads a motion registry artifact unless `--motion_file` is supplied.
- Resolves the G1 task as `gencoord` or `maxcoord`.
- Creates the vectorized mjlab environment and starts `SuperMimicRunner`.

The motion data enters through:

1. `download_registry_motions()` in `scripts/train_utils.py`
2. `motion_file` in the mjlab `MotionCommand`
3. `MotionLoader`, which provides joint poses/velocities and reference body poses/velocities

The real bundled motion data itself is not copied here. The code and registry
artifact paths are included, while local motion `.npz` files are runtime inputs.

## 2. Construction

`src/supermimic/runners/supermimic_runner.py`

`build_world_model()` constructs:

- a `StateRepresentation` (`GenCoordRepresentation` or `MaxCoordRepresentation`)
- `SimContext` from active domain-randomization events
- `Dynamics`, the differentiable learned transition model
- action scale/offset and empirical normalization state

`build_actor()` constructs `MultiEncoderAE`:

- one goal encoder per task (`motion`, and optionally `velocity`)
- a shared history/observation decoder
- per-task slot routing across parallel environments
- optional latent consistency loss between task encoders

## 3. Real-simulator collection loop

One `SuperMimicRunner.step()` call:

1. Read the current full state, actor sensor, motion time, and sim context.
2. Convert full state to a representation state and auxiliary state.
3. Build actor observations containing sensor history and per-task goals.
4. Run the actor to obtain raw policy actions.
5. Step the real mjlab environment.
6. Store `{state, action, prev_action, motion_time, termination flags, sim_ctx}`
   in `ReplayBuffer`.
7. Queue empirical-normalization updates for world-model and actor inputs.

The replay schema is in `_buffer_schema()`; storage/sampling is in
`src/supermimic/replay_buffer.py`.

For history length greater than one, the runner keeps a separate real-sim sensor
history ring and samples causal, done-aware history windows for warm starts.

## 4. World-model supervised training

`src/supermimic/learners/wm_learner.py`

For every replay window:

1. Sample a causal sequence of full states and raw actions.
2. Convert states to representation states and auxiliary states.
3. Roll out `Dynamics` autoregressively for `horizon - 1` transitions.
4. Compute predicted versus ground-truth representation losses.
5. Weight groups with nominal Bryson-rule errors.
6. Backpropagate through the world model and update it.

The transition is in `src/supermimic/models.py::Dynamics`:

`(representation_state, raw_action, auxiliary_state, sim_context)`
`-> (next_auxiliary_state, next_representation_state)`

Raw actions are mapped internally with action scale/offset. State and processed
action values are empirically normalized.

The two representation implementations in `representations.py` define:

- `represent()` and `apply_prediction()`
- auxiliary-state extraction
- loss channel groups
- world-model rewards
- actor-sensor synthesis
- motion-reference goal construction

## 5. Imagined policy training loop

`src/supermimic/envs/world_model_env.py`

`WorldModelEnv` replaces physics stepping with the learned dynamics:

1. Reset from a replay-buffer start state.
2. Construct the current sensor history and motion/task goals.
3. Run the actor to propose an action.
4. Step `Dynamics` once.
5. Synthesize the next sensor.
6. Advance the motion timeline.
7. Compute tracking reward and a differentiable/soft termination probability.

The policy learner in `learners/policy_learner.py` rolls the environment forward
for `horizon` imagined steps.

The `ActorCriticPolicyLearner` variant:

- maximizes the imagined discounted return through BPTT
- bootstraps with a critic
- computes GAE targets
- updates the critic from imagined critic observations
- applies survival masking and action-independent auxiliary actor loss

The plain `BpttPolicyLearner` variant has no critic bootstrap and directly
optimizes accumulated imagined return.

## 6. Reset sampling

`src/supermimic/runners/reset_sampling.py`

The default `return` sampling mode measures per-motion-bin returns from real
simulator collection. It combines:

- uniform exploration
- low-return focused sampling
- persistent effort-based keep sampling

The sampled distribution is written into the mjlab motion command, so real
collection biases starting states toward underperforming motion segments.

## 7. The complete alternating update

In `SuperMimicRunner.run()`:

1. Step the real environment and append transitions.
2. Flush empirical normalization.
3. Periodically sample replay windows and policy starts.
4. Update the world model by supervised autoregressive rollout.
5. Update the policy with imagined BPTT rollouts.
6. Repeat; log metrics and save `world_model.pt`, `actor.pt`, and optional
   `critic.pt`.
